package io.mosire.brain.subagent;

import io.mosire.agentlib.permission.ResourceScope;
import io.mosire.agentlib.permission.RoleSet;
import io.mosire.brain.permission.AgentRoles;
import io.mosire.brain.skills.SkillCatalog;
import io.mosire.brain.skills.SkillNamespaces;
import io.mosire.brain.skills.SkillPermissions;
import io.mosire.docs.DocNamespaces;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 子 Agent 子进程的启动命令模板（Rul C：Brain 不做文件系统假设——jar 路径/入口类/目录由装配层按当前 发行形态注入；本记录只是 "命令 + 参数前缀 + id
 * 参数名"的最小形状，不含任何路径探测）。
 *
 * <p><strong>W3b 扩展</strong>：{@code jvmArgs}（内存 cap 等 JVM 级参数插在命令与子命令前缀之间）、 {@code
 * templatesDir}/{@code childDataDir}（模板目录与子进程数据根目录注入）、{@code parentLink} （父侧已建 stdio 链接——子体以 MCP
 * client 身份运行并阻塞等待父侧关停信号）。 数据来自实例快照： {@code argv(SubagentInstance)} = 命令 + JVM 参数 + 前缀 + {@code
 * --id <实例id>} + {@code --template <模板id>} + {@code --goal <目标>} +（可选 {@code --templates-dir
 * <目录>}）+（可选 {@code --data-dir <根>/<实例id>}）+（可选 {@code --config-dir <目录>}）+（可选 {@code
 * --parent-link}）。
 *
 * <p><strong>技能面扩展（{@code skillsDir} + 两个范围项）</strong>：{@code --skills-dir <目录>} 给子体技能根（子进程据此
 * 做每回合的技能目录预注入）；{@code --skill-visible}/{@code --skill-editable} 由 {@code argv} 从<b>实例权限集</b>现算
 * （{@code *} = 不限 / {@code none} = 一个都不许 / 其余每个前缀一项），子进程据此恢复自己的技能可见面与可编辑面—— 子体的技能工具仍由父侧 MCP
 * 链接服务（权限集也是父侧那份），argv 这一份只服务“预注入不得越出可见面”。未表态的命名空间不追加任何项。
 *
 * <p><strong>技能目录档预算（D2，{@code skillsListingBudget}）</strong>：{@code --skills-listing-budget <整数>}
 * 给子体<b>目录档字符预算</b>（子进程用它建 {@code SkillCatalog}）。值与 {@code --skills-dir} <b>同源</b>（都由装配层从 {@code
 * skills.listingBudget} 下发）；<b>只有非缺省值才追加</b>——缺省（{@code SkillCatalog.DEFAULT_LISTING_BUDGET}）
 * 时子进程自己回落同一个数，因此既有装配与既有夹具的 argv <b>逐字不变</b>。{@code null} = 未注入（同"缺省"）。
 *
 * <p><strong>子工作区扩展（R3b，{@code --doc-visible}/{@code --doc-editable}）</strong>：与技能面同一条缝同一种编码—— 值由
 * {@code argv} 从<b>实例权限集</b>现算（子工作区的 {@code docs} 能力在 spawn 时已落格，见 {@code SubagentManager}），
 * 子进程据此恢复自己的文档可见面与可编辑面。未表态的命名空间不追加任何项；子进程侧对"缺席"的读法是 {@code none}（fail-closed）。
 *
 * <p><strong>角色维（第 8 维，{@code --roles}）</strong>：与上面三面同一条缝——值由 {@code argv} 从<b>实例权限集</b>现算
 * （父侧算出的生效角色 = {@code 调用者 ∩ 模板 ∩ 请求}），形态是逗号连接的升序角色名（编解码只有一份：{@code AgentRoles}）。
 * ⊥（一个角色都没有）<b>不追加旗标</b>：子进程侧的缺省读法就是 ⊥（fail-closed，不是"不限"），既有装配与既有夹具的 argv 因此逐字不变。 角色名不是密钥（设计
 * §4.3.1）⇒ 可以进 argv；但本类不打印、不记事件——角色名不进日志/事件面是明文面纪律。
 *
 * <p><strong>三期 S1-A2 扩展（{@code configDir}）</strong>：子 Agent 走真模型时它自己的 {@code --data-dir}
 * 是隔离目录，底下没有 {@code config.json}（配置在父的数据目录） ⇒ 装配层把父的配置根经本组件注入子进程。它是与 {@code templatesDir} 同性质的"注入
 * 值"（Rul C：Brain 不探测任何路径）；<b>只传路径、不传密钥值</b>——密钥由子进程自己从 {@code <configDir>/config.json} 读（D23）。
 *
 * @param command 可执行文件名（如 {@code java}）
 * @param jvmArgs JVM 级参数（如内存 cap；插在命令之后、子命令前缀之前；null/空 = 不传）
 * @param prefix 子命令前缀参数（如 {@code -jar <jar> agent}）
 * @param idFlag 实例 id 参数名（{@code --id}）
 * @param templatesDir 模板目录（装配层注入；<b>相对路径按父进程 CWD 绝对化</b>，见 {@code absoluteOrNull}；null =
 *     不传，子体按自身默认）
 * @param childDataDir 子 Agent 数据根目录（每实例取其 {@code <root>/<实例id>}；同上绝对化；null = 不传）
 * @param parentLink 是否带 {@code --parent-link}（父侧已建 stdio 链接，子体走 MCP client 形态）
 * @param configDir 父的配置根目录（装配层注入；同上绝对化；null = 不传——离线/测试形态，子体按自身默认）。<b>只放路径</b>：密钥值绝不经参数面
 *     （R-A2-3/D23）
 * @param skillsDir 技能根目录（装配层注入；同上绝对化；null = 不传——子体不做技能预注入）。子体的技能<b>可见/可编辑范围</b>不在这里， 而由 {@link
 *     #argv} 从实例权限集现算成 {@code --skill-visible}/{@code --skill-editable} 项——
 *     范围是权限数据，必须跟着权限集走（父级收紧过的才是子体该拿的），不能由装配层另配一份
 * @param skillsListingBudget 技能目录档字符预算（{@code --skills-listing-budget}；D2）。<b>null = 未注入</b> （子进程按
 *     {@link SkillCatalog#DEFAULT_LISTING_BUDGET} 回落）；等于缺省时 <b>不追加旗标</b>（argv 逐字不变， 子进程本来就回落同一个数）；0
 *     是合法取值（不披露目录档），负数在构造期具名拒
 */
public record AgentCommand(
    String command,
    List<String> jvmArgs,
    List<String> prefix,
    String idFlag,
    String templatesDir,
    String childDataDir,
    boolean parentLink,
    String configDir,
    String skillsDir,
    Integer skillsListingBudget) {

  public AgentCommand {
    if (command == null || command.isBlank()) {
      throw new IllegalArgumentException("命令不能为空");
    }
    jvmArgs = List.copyOf(jvmArgs == null ? List.of() : jvmArgs);
    prefix = List.copyOf(prefix == null ? List.of() : prefix);
    if (idFlag == null || idFlag.isBlank()) {
      throw new IllegalArgumentException("idFlag 不能为空");
    }
    if (skillsListingBudget != null && skillsListingBudget < 0) {
      // 与 SkillCatalog 同一口径：负预算是配置错误，不在这一层静默夹成 0
      throw new IllegalArgumentException("技能目录档预算不能为负: " + skillsListingBudget);
    }
    templatesDir = absoluteOrNull(templatesDir);
    childDataDir = absoluteOrNull(childDataDir);
    configDir = absoluteOrNull(configDir);
    skillsDir = absoluteOrNull(skillsDir);
  }

  /** 9 参兼容构造（D2 之前）：目录档预算<b>未注入</b>（{@code null} ⇒ 不追加旗标，子进程按缺省回落），因此既有调用点的 argv 逐字节不变。 */
  public AgentCommand(
      String command,
      List<String> jvmArgs,
      List<String> prefix,
      String idFlag,
      String templatesDir,
      String childDataDir,
      boolean parentLink,
      String configDir,
      String skillsDir) {
    this(
        command,
        jvmArgs,
        prefix,
        idFlag,
        templatesDir,
        childDataDir,
        parentLink,
        configDir,
        skillsDir,
        null);
  }

  /**
   * 注入路径一律<b>绝对化</b>（S5-E 实测缺陷）：子体的出生目录是它的 {@code fs} 可达面首根（{@code
   * SubProcessExecutor.startDirectory}，S5-D 的 L2），<b>与父进程 CWD 可以不同</b>——同一个相对路径在父子两侧会解析到
   * 两个位置。实测形态（父 Agent 配了 {@code agents.workingDirs} + 相对模板目录）：子体拿到 {@code --templates-dir
   * .work/…/s5-templates}，在出生目录里解析成 {@code <沙箱根>/.work/…}（不存在）⇒ 子体启动即退，父侧只看到一个 {@code
   * finished}，日志零行。
   *
   * <p>绝对化在<b>构造期</b>做（构造发生在父进程，解析基准 = 父的 CWD，与父装载这些目录时同源）；放在这里而不是各装配点，是
   * 因为"注入路径必须与父同源"是这个记录的契约，漏一处就复现一次。
   *
   * <p>只做 {@code toAbsolutePath().normalize()}：<b>不探测存在性</b>（Rul C——路径由装配层给定），也不做 realpath
   * （那会改变符号链接语义）。
   */
  private static String absoluteOrNull(String path) {
    return path == null ? null : Path.of(path).toAbsolutePath().normalize().toString();
  }

  /** W3a 兼容构造：无 JVM 参数、无目录注入、非链接模式。 */
  public AgentCommand(String command, List<String> prefix, String idFlag) {
    this(command, List.of(), prefix, idFlag, null, null, false);
  }

  /** 8 参兼容构造（技能根引入之前）：{@code skillsDir = null}（子体不做技能预注入，行为逐字不变）。 */
  public AgentCommand(
      String command,
      List<String> jvmArgs,
      List<String> prefix,
      String idFlag,
      String templatesDir,
      String childDataDir,
      boolean parentLink,
      String configDir) {
    this(command, jvmArgs, prefix, idFlag, templatesDir, childDataDir, parentLink, configDir, null);
  }

  /**
   * S1-A2 之前的 7 参形态的兼容构造（{@code configDir = null}）：既有调用点与既有 {@code AgentCommand} 用例零改动
   * （R-A2-5——"既有构造器一律传 null"）。
   */
  public AgentCommand(
      String command,
      List<String> jvmArgs,
      List<String> prefix,
      String idFlag,
      String templatesDir,
      String childDataDir,
      boolean parentLink) {
    this(command, jvmArgs, prefix, idFlag, templatesDir, childDataDir, parentLink, null);
  }

  /** 同 jar 形态：{@code <java> <jvmArgs> -jar <jarPath> agent --id <实例id>}（D4；jar 路径由装配层注入）。 */
  public static AgentCommand javaJar(String javaBinary, String jarPath) {
    return javaJar(javaBinary, List.of(), jarPath);
  }

  /** 同 jar 形态 + JVM 参数（W3b：内存 cap 等）。 */
  public static AgentCommand javaJar(String javaBinary, List<String> jvmArgs, String jarPath) {
    if (jarPath == null || jarPath.isBlank()) {
      throw new IllegalArgumentException("jarPath 不能为空");
    }
    return new AgentCommand(
        javaBinary,
        jvmArgs,
        List.of("-jar", jarPath, "agent"),
        "--id",
        null,
        null,
        false,
        null,
        null);
  }

  /**
   * classpath 形态：{@code <java> <jvmArgs> -cp <java.class.path> <mainClass> agent --id <实例id>}。
   *
   * <p>classpath 取 {@code System.getProperty("java.class.path")}——Rul C 允许的"当前进程自带 信息"，Brain
   * 侧仍不探测任何文件路径；其余参数由装配层给定。
   */
  public static AgentCommand javaClasspath(String javaBinary, String mainClass) {
    return javaClasspath(javaBinary, List.of(), mainClass);
  }

  /** classpath 形态 + JVM 参数。 */
  public static AgentCommand javaClasspath(
      String javaBinary, List<String> jvmArgs, String mainClass) {
    if (mainClass == null || mainClass.isBlank()) {
      throw new IllegalArgumentException("mainClass 不能为空");
    }
    return new AgentCommand(
        javaBinary,
        jvmArgs,
        List.of("-cp", System.getProperty("java.class.path", ""), mainClass, "agent"),
        "--id",
        null,
        null,
        false,
        null,
        null);
  }

  /** 以实例数据拼出完整命令行（命令 + JVM 参数 + 前缀 + 实例参数对 + 可选注入项）。 */
  List<String> argv(SubagentInstance instance) {
    Objects.requireNonNull(instance, "instance");
    List<String> argv = new ArrayList<>();
    argv.add(command);
    argv.addAll(jvmArgs);
    argv.addAll(prefix);
    argv.add(idFlag);
    argv.add(instance.instanceId());
    argv.add("--template");
    argv.add(instance.templateId());
    argv.add("--goal");
    argv.add(instance.goal());
    if (templatesDir != null) {
      argv.add("--templates-dir");
      argv.add(templatesDir);
    }
    if (childDataDir != null) {
      argv.add("--data-dir");
      argv.add(Path.of(childDataDir).resolve(instance.instanceId()).toString());
    }
    if (configDir != null) {
      // S1-A2：只追加路径——密钥值不在本方法可达的任何字段里（D23/R-A2-3）
      argv.add("--config-dir");
      argv.add(configDir);
    }
    if (parentLink) {
      argv.add("--parent-link");
    }
    if (skillsDir != null) {
      argv.add("--skills-dir");
      argv.add(skillsDir);
      // D2：目录档预算只在**非缺省**时下发——缺省（4096）由子进程自己回落同一个数，既有装配与既有夹具的 argv 因此逐字不变。
      if (skillsListingBudget != null
          && skillsListingBudget != SkillCatalog.DEFAULT_LISTING_BUDGET) {
        argv.add("--skills-listing-budget");
        argv.add(Integer.toString(skillsListingBudget));
      }
    }
    // 技能范围：只在该命名空间**已表态**时才追加（未接线技能面的既有装配 argv 逐字节不变）。取值直接来自实例权限集——
    // 父级收紧过的才是子体该拿的，装配层没有第二份可写的地方（写错一处就是静默放大）。
    appendScope(argv, instance, SkillNamespaces.SKILLS, "--skill-visible");
    appendScope(argv, instance, SkillNamespaces.SKILLS_EDIT, "--skill-editable");
    // 文档两个面（R3b）：与技能同一条缝、同一个编码（SkillPermissions.encode 是"ResourceScope → argv 项"的
    // 唯一实现，文档面复用它而不是另写一份编解码）。命名空间常量取自 DocNamespaces——不在这里抄字符串。
    appendScope(argv, instance, DocNamespaces.DOCS, "--doc-visible");
    appendScope(argv, instance, DocNamespaces.DOCS_EDIT, "--doc-editable");
    // 角色（第 8 维，设计 §4.5）：取值的唯一来源同样是**实例权限集**（父侧算出的生效值 = 调用者 ∩ 模板 ∩ 请求）——
    // 装配层没有第二份可写的地方，写错一处就是静默放大。⊥（一个角色都没有）**不追加旗标**：子进程侧的缺省读法就是 ⊥
    // （fail-closed），既有装配与既有夹具的 argv 因此逐字不变。角色名不是密钥（设计 §4.3.1）⇒ 可以进 argv；
    // 但这里不打印、不记事件（明文面纪律）。
    RoleSet roles = instance.permissions().roles();
    if (!roles.roles().isEmpty()) {
      argv.add("--roles");
      argv.add(AgentRoles.encode(roles));
    }
    return argv;
  }

  /** 把一个已表态的作用域编码成重复的 argv 项（未表态 = 不追加，见 {@link #argv}）。技能面与文档面共用（编码只有一处）。 */
  private static void appendScope(
      List<String> argv, SubagentInstance instance, String namespace, String flag) {
    ResourceScope scope = instance.permissions().resourceScopes().declaredScope(namespace);
    if (scope == null) {
      return;
    }
    for (String item : SkillPermissions.encode(scope)) {
      argv.add(flag);
      argv.add(item);
    }
  }
}
